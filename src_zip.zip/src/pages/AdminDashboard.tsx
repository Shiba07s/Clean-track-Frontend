/**
 * Admin Dashboard Page
 * Displays all complaints in a table with approve/reject functionality.
 * Status changes are simulated (UI only, no backend).
 */
import { useState } from "react";
import { mockReports, Report } from "@/data/mockData";
import StatusBadge from "@/components/StatusBadge";
import { Shield } from "lucide-react";

const AdminDashboard = () => {
  // Local state to manage report statuses (simulate approve/reject)
  const [reports, setReports] = useState<Report[]>([...mockReports]);

  // Handle status change for a report
  const handleStatusChange = (id: number, newStatus: "Approved" | "Rejected") => {
    setReports((prev) =>
      prev.map((report) =>
        report.id === id
          ? { ...report, status: newStatus, rewardPoints: newStatus === "Approved" ? 20 : 0 }
          : report
      )
    );
  };

  return (
    <div className="container-page">
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <Shield className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Review and manage pollution reports.</p>
        </div>
      </div>

      {/* Complaints Table */}
      <div className="bg-card border rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">ID</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Image</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Location</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Date</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Status</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {reports.map((report) => (
                <tr key={report.id} className="border-b last:border-0 hover:bg-muted/30">
                  <td className="p-4 text-sm font-medium">#{report.id}</td>
                  <td className="p-4">
                    <img
                      src={report.image}
                      alt="Report"
                      className="w-16 h-12 rounded object-cover"
                    />
                  </td>
                  <td className="p-4 text-sm">{report.location}</td>
                  <td className="p-4 text-sm">{report.date}</td>
                  <td className="p-4">
                    <StatusBadge status={report.status} />
                  </td>
                  <td className="p-4">
                    <div className="flex gap-2">
                      {/* Approve Button */}
                      <button
                        onClick={() => handleStatusChange(report.id, "Approved")}
                        disabled={report.status === "Approved"}
                        className="px-3 py-1 text-xs font-medium bg-success text-success-foreground rounded hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
                      >
                        Approve
                      </button>
                      {/* Reject Button */}
                      <button
                        onClick={() => handleStatusChange(report.id, "Rejected")}
                        disabled={report.status === "Rejected"}
                        className="px-3 py-1 text-xs font-medium bg-destructive text-destructive-foreground rounded hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
                      >
                        Reject
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
